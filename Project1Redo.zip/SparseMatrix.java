
public class SparseMatrix implements SparseInterface {
	// Initialize Global Variables
	private int numRows;
	private int numCols;
    private int row;
    private int col;
    private int data;
	private SparseMatrix head;
    private SparseMatrix next;

    // Constructor
    public SparseMatrix() {
        this.numRows = 5;
        this.numCols = 5;
        this.head = null;
        this.next = null;
    }
    
    // Node Method
    public SparseMatrix(int r, int c, int d) {
        this.row = r;
        this.col = c;
        this.data = d;
    }
    
    // Node Row Getter
    public int getRow() {
        return this.row;
    }
    
    // Node Column Getter
    public int getCol() {
        return this.col;
    }
    
    // Node Data Getter
    public int getData() {
        return this.data;
    }
    
    // Node Next Getter
    public SparseMatrix next() {
        return this.next;
    }
    
    // Node Next Node Setter
    public void setSuccNode(SparseMatrix succNode) {
        this.next = succNode;
    }
    
    // Clears the matrix of all elements
	public void clear() {
		this.head = null;
	}
	
	// Sets the size of the rows and columns of the matrix
	public void setSize(int numRows, int numCols) {
		this.numRows = numRows;
		this.numCols = numCols;
        this.head = null;
	}
	
	// Gets the number of rows in the matrix
	public int getNumRows() {
		return this.numRows;
	}
	
	// Gets the number of columns in the matrix
	public int getNumCols() {
		return this.numCols;
	}
	
	private boolean isOutOfBounds(int row, int col) {
		return this.getNumRows() <= row || this.getNumCols() <= col || row < 0 || col < 0;
	}
	
	// Adds data value in the desired index
	public void addElement(int row, int col, int data) {
		
		// Exception thrown when user inputs invalid matrix position
		if( isOutOfBounds(row, col) ) {
            try {
            	throw new IndexOutOfBoundsException();
            } catch (IndexOutOfBoundsException e) {
            	System.out.println("Error! Adding an element to (" + row + ", " + col + ") is out of bounds!");
            }
            return;
        }
     	// Adding a zero to memory results in removing the element
     	if( data == 0 ) {
     		this.removeElement(row, col);
     		return;
     	}
		// Creates a new node for the first value entered
        if( this.head == null ) {
            this.head = new SparseMatrix(row, col, data);
            return;
        }
        // Redirects the head pointer
        if( this.head.getRow() == row && this.head.getCol() == col ) {
        	SparseMatrix newNode = new SparseMatrix(row, col, data);
            newNode.setSuccNode(this.head.next());
            this.head = newNode;
            return;
        }
        // Redirects the proper values for the head pointer and newNode pointer
        if( (this.head.getRow() > row) || (this.head.getRow() == row && this.head.getCol() > col) ) {
        	SparseMatrix newNode = new SparseMatrix(row, col, data);
            newNode.setSuccNode(this.head);
            this.head = newNode;
            return; 
        } else {
        	// Initializes appropriate pointer values
        	SparseMatrix newNode = new SparseMatrix(row, col, data);
        	SparseMatrix currNode = this.head;
        	
        	// Runs when the currNode is at the end of the list
            if( currNode.next() == null ) {
                if( currNode.getRow() > row || (newNode.getRow() == currNode.getRow()) && (currNode.getCol() > col) ) {
                    newNode.setSuccNode(currNode);
                    this.head = newNode;
                } else {
                    currNode.setSuccNode(newNode);
                }
                return;
            }
            // Iterate through the list of elements if it's not the first element
            while( currNode.next() != null ) {
            	// Redirects the pointers when currentNode row is after row
                if( currNode.next().getRow() > row ) {
                    newNode.setSuccNode(currNode.next());
                    currNode.setSuccNode(newNode);
                    return;
                }
                // Redirects the pointers when at the position
                if( currNode.next().getRow() == row && currNode.next().getCol() == col ) {
                    newNode.setSuccNode(currNode.next().next());
                    currNode.setSuccNode(newNode);
                    return;
                }
                // Redirects the pointers when at the row
                if( currNode.next().getRow() == row ) {
                	// Redirects the pointers when currentNode column is after column
                    if( currNode.next().getCol() > col ) {
                        newNode.setSuccNode(currNode.next());
                        currNode.setSuccNode(newNode);
                        return;
                    }
                    // Redirects the pointers when currentNode column is before column
                    if( currNode.next().getCol() < col ) {
                        if( currNode.next().next() == null ) {
                            currNode.next().setSuccNode(newNode);
                            return;
                        } else if( currNode.next().next().getCol() < col ) {
                            currNode = currNode.next();
                            continue;
                        } else {
                            newNode.setSuccNode(currNode.next().next());
                            currNode.next().setSuccNode(newNode);
                            return;
                        }
                    }
                }
                // Redirects the pointers when currentNode is at the end of the list
                if( currNode.next().next() == null ){
                    if( currNode.next().getRow() > row || (newNode.getRow() == currNode.next().getRow()) && (currNode.next().getCol() > col) ) {
                        newNode.setSuccNode(currNode.next());
                        currNode.setSuccNode(newNode);
                    } else {
                        currNode.next().setSuccNode(newNode);
                    }
                    return;
                }
                currNode = currNode.next();
            }
        }
	}
	
	// Removes the data value from desired index
	public void removeElement(int row, int col) {
		
		// Exception thrown when user inputs invalid matrix position
		if( isOutOfBounds(row, col) ) {
            try {
            	throw new IndexOutOfBoundsException();
            } catch (IndexOutOfBoundsException e) {
            	System.out.println("Error! Removing an element from (" + row + ", " + col + ") is out of bounds!");
            }
            return;
        }
		// Assigns currNode the head pointer
        SparseMatrix currNode = this.head;
        
        // Checks if there is an element in the position
        if( this.head == null ) {
        	return;
        }
        // First element to be removed
        if( this.head.getRow() == row && this.head.getCol() == col ) {
            if( this.head.next() == null ) {
                this.head = null;
                return;
            } else {
                this.head = this.head.next();
            return;
            }
        } else {
        	// Iterate through the list of elements if it's not the first element
            while( currNode.next() != null ){
                if( currNode.next().getRow() == row && currNode.next().getCol() == col ) {
                	// When the element is last in the list
                    if( currNode.next().next() == null ) {
                        currNode.setSuccNode(null);
                        return;
                    } else {
                        currNode.setSuccNode(currNode.next().next());
                        return;
                    }
                }
                currNode = currNode.next();
            }
        }
	}
	
	// Gets the data value from desired index
	public int getElement(int row, int col) {
		
        // Exception thrown when user inputs invalid matrix position
		if( isOutOfBounds(row, col) ) {
            try {
            	throw new IndexOutOfBoundsException();
            } catch (IndexOutOfBoundsException e) {
            	System.out.println("Error! Element at (" + row + ", " + col + ") does not exist because it's out of bounds!");
            }
            return 0;
        }
		// Empty matrix returns zero
        if( this.head == null ) {
            return 0;
        }
        // Assigns currNode the head pointer
        SparseMatrix currNode = this.head;
        
        // Runs when the currNode is at the end of the list
        if( currNode.next() == null ) {
            if( currNode.getRow() == row && currNode.getCol() == col ) {
                return currNode.getData();
            } else {
                return 0;
            }
        }    
        // Iterate through the list of elements if it's not the first element
        while( currNode.next()!= null ) {
        	// Returns the data of the index
            if( currNode.getRow() == row && currNode.getCol() == col ) {
                return currNode.getData();
            } else {
                currNode = currNode.next();
                // Returns the data of the tail, otherwise it is zero
                if( currNode.next() == null ) {
                    if( currNode.getRow() == row && currNode.getCol() == col ) {
                        return currNode.getData();
                    } else {
                        return 0;
                    }
                }
            }
        }
        return 0;
	}
	
	// Prints all nonzero elements of the sparse matrix as a string
	public String toString() {
		StringBuilder sparseMatrix = new StringBuilder();
		// Assigns currNode the head pointer
		SparseMatrix currNode = this.head;
		
		// When matrix is empty		
        if( currNode == null ) {
            return ("");
        }
        // Iterates through the matrix list and prints data values
        while( currNode != null ) {
        	sparseMatrix.append(Integer.toString(currNode.getRow()) + " "  + Integer.toString(currNode.getCol()) + " " + Integer.toString(currNode.getData()) + "\n");
            currNode = currNode.next();
        }
        return sparseMatrix.toString();
	}
	
	// Adds matrices together
	public SparseInterface addMatrices(SparseInterface matrixToAdd) {
		// Exception thrown when user inputs invalid matrix dimensions
		if( (this.getNumRows() != matrixToAdd.getNumRows()) || (this.getNumCols() != matrixToAdd.getNumCols()) ) {
			System.out.println("Error! You cannot add because dimensions do not match!");
			return null;
		}
		// Creates matrix object to be added with the matrixToAdd
		SparseMatrix result = new SparseMatrix();
		result = this;
		
		// Computes the addition of two matrices with computational complexity of O(n^2)
		for( int i = 0; i < this.getNumRows(); i++ ) {
			for( int j = 0; j < this.getNumCols(); j++ ) {
				result.addElement(i, j, this.getElement(i, j) + matrixToAdd.getElement(i, j));
			}
		}
		return result;
	}
	
	// Multiplies matrices together
	public SparseInterface multiplyMatrices(SparseInterface matrixToMultiply) {
		// Exception thrown when user inputs invalid matrix dimensions
		if( (this.getNumCols() != matrixToMultiply.getNumRows()) ) {
			System.out.println("Error! You cannot multiply because dimensions do not agree!");
			return null;
		}
		// Creates matrix object to be multiplied with the matrixToMultiply also known as otherMatrix
		SparseMatrix result = new SparseMatrix();
		SparseMatrix otherMatrix = ((SparseMatrix) matrixToMultiply);
		
		// Computes the multiplication of two matrices with computational complexity of O(n^3)
		for( int i = 0; i < this.getNumRows(); i++ ) {
			for( int j = 0; j < otherMatrix.getNumCols(); j++ ) {
				int total = 0;
				for( int k = 0; k < this.getNumCols(); k++ ) {
					total += this.getElement(i, k) * otherMatrix.getElement(k, j);
				}
				result.addElement(i, j, total);
			}
		}
		return result;
	}
}
