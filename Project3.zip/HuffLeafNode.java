
class HuffLeafNode implements HuffBaseNode {
  private char element;
  private int weight;

  HuffLeafNode(char element, int weight) {
	  this.element = element; 
	  this.weight = weight; 
  }

  public char value() { 
	  return this.element; 
  }

  public int weight() { 
	  return this.weight; 
  }
  
  public boolean isLeaf() { 
	  return true; 
  }
}