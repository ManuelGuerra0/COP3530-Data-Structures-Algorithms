import java.io.File;
import java.io.FileNotFoundException;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class HuffmanEncoder implements HuffmanCoding{
	
	//take a file as input and create a table with characters and frequencies
	//print the characters and frequencies
	public String getFrequencies(File inputFile) throws FileNotFoundException{
		
		// Initializes array for ASCII characters up to 128
		int[] freq = new int[128];
		// Collects contents of the input file
		Scanner contentOfTextFile = new Scanner(inputFile).useDelimiter("");

		// Stores the frequency of each character in the array
		while (contentOfTextFile.hasNext()) {
			freq[contentOfTextFile.next().charAt(0)]++;
		}
		// Initializes frequency table string as empty
		String frequencyTable = "";

		// Starts with ASCII value 32 (space) to 127 (backspace)
		for (int i = 32; i < 128; i++) {
			// Character with no occurrence is not included in the string table
			if (freq[i] == 0) {
				continue;
			}
			// Appends ASCII character at i and it's frequency in the array
			frequencyTable += String.valueOf((char)i) + "|" + freq[i] + "\n";
		}
		//return the string we have created
		return frequencyTable;
	}
	
	//take a file as input and create a Huffman Tree
	public HuffTree buildTree(File inputFile) throws FileNotFoundException, Exception{
		
		// Array for character frequencies is passed onto this method
		int[] freq = new int[128];
		Scanner contentOfTextFile = new Scanner(inputFile).useDelimiter("");
		while (contentOfTextFile.hasNext()) {
			freq[contentOfTextFile.next().charAt(0)]++;
		}
		
		// Creates a comparator for characters frequencies between the 1st and 2nd trees passed
		Comparator<HuffTree> characterFrequency = new Comparator<HuffTree>() {
			public int compare(HuffTree a, HuffTree b) {
				return a.weight() - b.weight();
			}
		};
		
		// Creates a priority queue of character frequencies and casts them as HuffTrees
		ArrayList<HuffTree> priorityQueue = new ArrayList<HuffTree>();
		for(int i = 32; i < 128; i++) {
			if(freq[i] > 0) {
				priorityQueue.add(new HuffTree((char)i, freq[i]));
			}
		}
		
		// Sorts frequencies in ascending ASCII order
		Collections.sort(priorityQueue, characterFrequency);
		
		// Returns null if there's nothing in the priority queue
		if( priorityQueue.size() == 0 ) { 
			return null;
		}
		
		// Initialization of the 3 trees needed to make the Huffman Tree
		HuffTree tempTree1 = null;
		HuffTree tempTree2 = null;
		HuffTree tempTree3 = null;
		
		// Gets the nodes and weights of both tempTree1 and tempTree2 for the final HuffTree
		while (priorityQueue.size() > 1) {
			tempTree1 = priorityQueue.get(0);
			priorityQueue.remove(0);
			tempTree2 = priorityQueue.get(0);
			priorityQueue.remove(0);
			tempTree3 = new HuffTree(tempTree1.root(), tempTree2.root(), tempTree1.weight() + tempTree2.weight());
			priorityQueue.add(tempTree3);
			Collections.sort(priorityQueue, characterFrequency);
		}
		// Returns tree of type HuffTree
		return priorityQueue.get(0);
	}
	
	//take a file and a HuffTree and encode the file.  
	//output a string of 1's and 0's representing the file
	public String encodeFile(File inputFile, HuffTree huffTree) throws FileNotFoundException{
		
		// Exception handling
		if (inputFile == null || huffTree == null) {
			return null;
		}
		// Creates Hashtable of Strings
		Hashtable<String, String> table = new Hashtable<String, String>();
		String code = "";
		
		// Content of text file passes through code algorithm
		Scanner contentOfTextFile = new Scanner(inputFile).useDelimiter("");
	      while (contentOfTextFile.hasNext()) {
	        String words = table.get((int)contentOfTextFile.next().charAt(0));
	        if(words == null) {
	          continue;
	        }
	        code += words;
	      }
	      // Returns string of encryted text
	    return code;
	}

	//take a String and HuffTree and output the decoded words
	public String decodeFile(String code, HuffTree huffTree) throws Exception{
		
		// Exception handling
		if (code == null || huffTree == null) {
			return null;
		}
		// Initialization of StringBuilder codes
		StringBuilder coded = new StringBuilder(code);
		StringBuilder decoded = new StringBuilder();

		// Returns the original text from encryted code
		return decoded.toString();
	}

	//print the characters and their codes
	public String traverseHuffmanTree(HuffTree huffTree) throws Exception{
		
		// Initialization of String array for Huffman Tree values
		// Initialization of StringBuilder for easy compilation of character Huffman codes
		String[] treeValue = new String[128];
		StringBuilder characterCodes = new StringBuilder();
		
		// Calls the recursive traverseTree method in the HuffTree class
		huffTree.codeTraversal(huffTree.root(), treeValue);
		
		//append the characters to the string in ascending ascii order
		for (int i = 0; i < 128; i++) {
			// Skips iteration if value doesn't exist
			if (treeValue[i] == null) {
				continue;
			}
			// Builds string of ASCII character and Huffman Tree Code
			characterCodes.append(((char)(i)) + "|" + treeValue[i] + "\n");
			//Collections.sort(characterCodes, treeValue[i]);
		}
		// Returns the complete traversal of the Huffman Tree as a string
		return characterCodes.toString();
	}
}
