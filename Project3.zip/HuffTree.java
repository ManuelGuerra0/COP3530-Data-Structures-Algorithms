import java.util.ArrayList;
import java.util.Scanner;

class HuffTree implements Comparable {
	private HuffBaseNode root; 
	
	public HuffBaseNode root() { 
		return root; 
	}
  
	public int weight() {
		return root.weight(); 
	}
	
	public HuffTree(HuffBaseNode root) {
		this.root = root;
	}

	public HuffTree(char element, int weight) {
		this.root = new HuffLeafNode(element, weight); 
	}
  
	public HuffTree(HuffBaseNode left, HuffBaseNode right, int weight) {
		this.root = new HuffInternalNode(left, right, weight); 
	}

	public void codeTraversal(HuffBaseNode node, String[] treeValue) {
		if (treeValue == null || node == null || node.isLeaf()) {
			return;
		}
		codeRecursion(((HuffInternalNode)(node)).right(), treeValue, "1");
		codeRecursion(((HuffInternalNode)(node)).left(), treeValue, "0");
	}
  
	public int compareTo(Object t) {
	    HuffTree that = (HuffTree)t;
	    if (root.weight() < that.weight()) return -1;
	    else if (root.weight() == that.weight()) return 0;
	    else return 1;
	}
	
	public void codeRecursion(HuffBaseNode node, String[] treeValue, String characterCode) {
		if (node.isLeaf()) {
			treeValue[((HuffLeafNode)node).value()] = characterCode;
		} else {
			codeRecursion(((HuffInternalNode)(node)).right(), treeValue, characterCode + "1");
			codeRecursion(((HuffInternalNode)(node)).left(), treeValue, characterCode + "0");
		}
	}
}