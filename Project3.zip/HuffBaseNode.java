
interface HuffBaseNode {
	boolean isLeaf(); 
	int weight();
}